package com.example.seed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
