import 'package:flutter/material.dart';
import 'package:seed/core/constants/app_colors.dart';

class PrimaryTextButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;

  const PrimaryTextButton({
    super.key,
    required this.text,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      style: TextButton.styleFrom(
        // primary: AppColors.whiteTextColor, // Text color
        minimumSize: Size(double.infinity, 50), // Same width as TextFormField
        padding: EdgeInsets.zero, // Remove padding
      ),
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(fontSize: 15,color: Colors.white), // Text size
      ),
    );
  }
}
