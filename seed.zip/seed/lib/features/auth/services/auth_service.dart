import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:seed/core/constants/app_constants.dart';
import 'package:seed/core/shared_preferences/shared_preferences.dart';
import 'package:seed/features/auth/controllers/auth_provider.dart';
import 'package:seed/features/user/home/presentation/dashboard.dart';

class AuthService {
  final WidgetRef ref;

  AuthService(this.ref);

  Future<void> handleLogin(
      BuildContext context, String email, String password) async {
    final authService = ref.read(firebaseAuthServiceProvider);
    final success = await authService.signIn(
        context: context, email: email, password: password);
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Login Successfully')),
      );
        Future.delayed(Duration(milliseconds: 500), () {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => UserDashBoardScreen()));
        });

    }
  }
  Future<void> handleRegister(
      BuildContext context, String name, String email, String password) async {
    final authService = ref.read(firebaseAuthServiceProvider);
    final success = await authService.signUp(
        context: context, name: name, email: email, password: password);

    if (success) {
      // Registration successful, navigate to next screen
      Future.delayed(Duration(milliseconds: 500), () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Registration Successfully')),
        );
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => UserDashBoardScreen()));
      });
    } else {
      // Handle registration failure (e.g., show an error message)
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Registration failed, please try again.')),
      );
    }
  }
  Future<void> handleForgetPassword(BuildContext context, String email) async {
    await ref
        .read(firebaseAuthServiceProvider)
        .resetPassword(context: context, email: email);
  }
}
