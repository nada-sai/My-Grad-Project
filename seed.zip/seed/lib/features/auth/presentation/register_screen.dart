import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:seed/core/constants/app_colors.dart';
import 'package:seed/core/constants/app_constants.dart';
import 'package:seed/core/constants/app_images.dart';
import 'package:seed/core/widgets/LogoDisplay.dart';
import 'package:seed/core/widgets/PrimaryTextButton.dart';
import 'package:seed/core/widgets/background_screen.dart';
import 'package:seed/features/auth/controllers/timer.dart';
import 'package:seed/features/auth/presentation/auth_screen.dart';
import 'package:seed/features/auth/presentation/register_form.dart';
import 'package:seed/features/auth/services/auth_service.dart';
import '../controllers/toggle_index_notifier.dart';
import 'forget_password_form.dart';
import 'login_form.dart';
import 'widgets/AuthToggleButtons.dart';
import 'widgets/BlurredContainer.dart';

class RegisterScreen extends ConsumerWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final _formKey = GlobalKey<FormState>();
    final _emailController = TextEditingController();
    final _passwordController = TextEditingController();
    final _nameController = TextEditingController();
    final authService = AuthService(ref);
    final selectedIndex = ref.watch(toggleIndexProvider);
    final countdown = ref.watch(timerProvider);

    return Scaffold(
      body: BackgroundScreen(
        // backgroundColor: AppColors.secondaryColor,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Positioned.fill(
                child: Stack(
                  children: [
                    Image.asset(
                      AppImages.splashBackground, // Replace with the image path
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    ),
                    Container(
                      color: Colors.black.withOpacity(0.3), // Black layer with 50% opacity
                      width: double.infinity,
                      height: double.infinity,
                    ),
                  ],
                )
                ,
              ),

              Column(
                children: [
                  LogoDisplay(),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: paddingVertical-20),
                    child: BlurredContainer(
                      child: RegisterForm(
                        emailController: _emailController,
                        passwordController: _passwordController,
                        nameController: _nameController,
                        formKey: _formKey,
                        authService: authService,
                      )
                    ),
                  ),
                  PrimaryTextButton(text: 'Have an account? Login',onPressed: ()
                  {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => LoginScreen()),
                    );
                  },),

                  SizedBox(height: 100,),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
