import 'package:flutter_riverpod/flutter_riverpod.dart';

class ToggleIndexNotifier extends StateNotifier<int> {
  ToggleIndexNotifier() : super(0); // Initial index is 0 (Login)

  void setIndex(int index) {
    state = index; // Update the index
  }
}

// Provider for the ToggleIndexNotifier
final toggleIndexProvider = StateNotifierProvider<ToggleIndexNotifier, int>((ref) {
  return ToggleIndexNotifier();
});
