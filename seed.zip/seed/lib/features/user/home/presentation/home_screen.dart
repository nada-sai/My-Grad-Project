import 'dart:io'; // For handling file
import 'dart:convert'; // For JSON decoding
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart'; // For image picking
import 'package:http/http.dart' as http; // For sending HTTP requests
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:seed/core/constants/app_colors.dart';
import 'package:seed/core/utils/dimensions.dart';
import 'package:seed/core/widgets/background_screen.dart';
import 'package:url_launcher/url_launcher.dart';

import 'widgets/CarouselBanner.dart';
import 'widgets/custom_app_bar.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  File? _pickedImage; // Store the picked image
  String _result = ""; // Store the result from the API
  // Method to check if a string contains a URL
  bool _containsUrl(String text) {
    final urlPattern = r'(https?://[^\s]+)';
    final regExp = RegExp(urlPattern);
    return regExp.hasMatch(text);
  }

  String? _url; // Store the URL if detected in the result

  // Method to extract the URL from the result text
  String? _extractUrl(String text) {
    final urlPattern = r'(https?://[^\s]+)';
    final regExp = RegExp(urlPattern);
    final match = regExp.firstMatch(text);
    return match?.group(0);
  }

  // Method to open the URL
  Future<void> _openUrl() async {
    if (_url != null) {
        await launchUrl(Uri.parse(_url!));
        throw 'Could not launch $_url';

    }
  }
  // Method to pick an image from camera or gallery
  Future<void> _pickImage(BuildContext context) async {
    final picker = ImagePicker();

    final pickedFile = await showDialog<XFile?>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Image Source'),
          actions: <Widget>[
            // Camera option
            TextButton(
              onPressed: () async {
                final file = await picker.pickImage(source: ImageSource.camera);
                Navigator.of(context).pop(file);
              },
              child: Text('Camera'),
            ),
            // Gallery option
            TextButton(
              onPressed: () async {
                final file =
                await picker.pickImage(source: ImageSource.gallery);
                Navigator.of(context).pop(file);
              },
              child: Text('Gallery'),
            ),
          ],
        );
      },
    );

    if (pickedFile != null) {
      setState(() {
        _pickedImage = File(pickedFile.path); // Store the picked image
      });
    }
  }

  // Method to remove the picked image
  void _removeImage() {
    setState(() {
      _pickedImage = null; // Set the image to null to remove it
      _result = ""; // Reset result
    });
  }

  bool _isLoading = false;

  // Method to send the image to the API
  Future<void> _sendImageToAPI() async {
    if (_pickedImage == null) return;
    setState(() {
      _isLoading = true;
    });
    // Replace with your API endpoint
    final String url =
        'https://seedflask-bzdndqc3g5bwgxdt.uaenorth-01.azurewebsites.net/predict';

    var request = http.MultipartRequest('POST', Uri.parse(url))
      ..files
          .add(await http.MultipartFile.fromPath('image', _pickedImage!.path));

    try {
      var response = await request.send();


      if (response.statusCode == 200) {
        final responseBody = await http.Response.fromStream(response);
        final result = json.decode(responseBody.body);
        setState(() {
          _result = result['result']; // Assuming the API returns a "result" key
          _url =_extractUrl(_result);
          _isLoading = false;
        });
      } else {
        setState(() {
          _result = 'Error: Failed to upload image';
          _isLoading = false;
        });
      }
    } catch (e) {
      print(e);
      setState(() {
        _result = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBarColor,
      appBar: CustomAppBar(title: 'Seed-Guard'),
      body: BackgroundScreen(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                child: GestureDetector(
                  onTap: () {},
                  child: CarouselBanner(),
                ),
              ),
              // Show the picked image if available
              if (_pickedImage != null)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Stack(
                    children: [
                      Image.file(
                        _pickedImage!,
                        height: 400,
                        width: 300,
                        fit: BoxFit.cover,
                      ),
                      Positioned(
                        top: 5,
                        right: 5,
                        child: GestureDetector(
                          onTap: _removeImage,
                          // Remove image when "X" is tapped
                          child: Container(
                            decoration: BoxDecoration(
                                color: AppColors.errorColor,
                                borderRadius: BorderRadius.circular(50)),
                            child: Padding(
                              padding: const EdgeInsets.all(3.0),
                              child: Icon(
                                Icons.close,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              // Button to open the camera or gallery with styling
              SizedBox(height: 25),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryColor, // Background color
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Rounded corners
                  ),
                  padding: EdgeInsets.symmetric(
                    vertical: 15, // Vertical padding
                    horizontal: 30, // Horizontal padding
                  ),
                ),
                onPressed: () {
                  _pickImage(context); // Trigger the image picking dialog
                },
                child: Text(
                  // _pickedImage == null
                  'Open Camera or Select Image',
                  // : 'Send to Check',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              SizedBox(height: 25),
              // Display the result from the API
              if (_result.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      // Use RichText for mixed styling
                      RichText(
                        textAlign: TextAlign.start,
                        text: TextSpan(
                          children: [
                            // Regular text in black color
                            TextSpan(
                              text: _result.replaceAll(_url ?? '', ''),
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            // If URL is detected, make it blue and clickable
                            if (_url != null)
                              TextSpan(
                                text: _url!,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue,
                                  decoration: TextDecoration.underline,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = _openUrl, // Launch the URL when tapped
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),              // Send image to the API if an image is selected
              if (_pickedImage != null&&_result.isEmpty)
                _isLoading == false
                    ? ElevatedButton(
                  onPressed: _sendImageToAPI,
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                    AppColors.primaryColor, // Background color
                    shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(10), // Rounded corners
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 15, // Vertical padding
                      horizontal: 30, // Horizontal padding
                    ),
                  ),
                  child: Text(
                    'Check Image',
                    style: TextStyle(color: Colors.white),
                  ),
                )
                    : LoadingAnimationWidget.twistingDots(
                  leftDotColor: const Color(0xFF1A1A3F),
                  rightDotColor: const Color(0xFFEA3799),
                  size: 30,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
