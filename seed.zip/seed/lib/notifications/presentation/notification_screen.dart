import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' as intl;  // Import DateFormat class
import 'package:seed/notifications/presentation/data/notification_model.dart';
import 'package:seed/core/widgets/primary_app_bar.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // List of NotificationModels with real data (simulated)
    final notifications = [
      // Adding seeds of Soybean, Rice, and Pistachio with detailed descriptions
      NotificationModel(
        title: 'Best Time for Planting: Soybeans',
        description: 'Soybeans are an essential crop for nitrogen fixation in the soil. Plant them in early spring for best results. Soybeans prefer well-drained, loamy soils with a pH between 6.0 and 7.5. Harvest occurs in late summer or early fall.',
        notificationDate: DateTime(2025, 3, 11),
        bestTimeDate: DateTime(2025, 3, 11),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Rice',
        description: 'Rice requires warm temperatures and a lot of water. It is best planted in fields that can be flooded during the growing season. The best time to plant rice is during the rainy season, from June to August. Rice is harvested in late autumn.',
        notificationDate: DateTime(2025, 3, 12),
        bestTimeDate: DateTime(2025, 3, 12),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Pistachios',
        description: 'Pistachios thrive in hot, dry climates and are best planted in well-drained sandy or loamy soil. Plant pistachios in early spring. They require a long growing season and are harvested in late summer or early fall. Pistachio trees need at least 4-5 years to start producing nuts.',
        notificationDate: DateTime(2025, 3, 13),
        bestTimeDate: DateTime(2025, 3, 13),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Tomatoes',
        description: 'The best time to plant tomatoes is during spring, from March to May.',
        notificationDate: DateTime(2025, 3, 1),
        bestTimeDate: DateTime(2025, 3, 1),
      ),
      NotificationModel(
        title: 'Proper Storage of Potatoes',
        description: 'Potatoes should be stored in a cool, dry place, away from light.',
        notificationDate: DateTime(2025, 3, 2),
        bestTimeDate: DateTime(2025, 3, 2),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Beans',
        description: 'The ideal time to plant beans is from mid-spring to early summer.',
        notificationDate: DateTime(2025, 3, 3),
        bestTimeDate: DateTime(2025, 3, 3),
      ),
      NotificationModel(
        title: 'Storage of Leafy Vegetables',
        description: 'Store leafy vegetables in the fridge in plastic bags to maintain their freshness.',
        notificationDate: DateTime(2025, 3, 4),
        bestTimeDate: DateTime(2025, 3, 4),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Carrots',
        description: 'Carrots should be planted in the spring, from March to April.',
        notificationDate: DateTime(2025, 3, 5),
        bestTimeDate: DateTime(2025, 3, 5),
      ),
      NotificationModel(
        title: 'Proper Storage of Tomatoes',
        description: 'Store tomatoes at room temperature, away from direct light.',
        notificationDate: DateTime(2025, 3, 6),
        bestTimeDate: DateTime(2025, 3, 6),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Eggplant',
        description: 'The best time to plant eggplant is in early summer.',
        notificationDate: DateTime(2025, 3, 7),
        bestTimeDate: DateTime(2025, 3, 7),
      ),
      NotificationModel(
        title: 'Proper Storage of Cucumbers',
        description: 'Store cucumbers in the fridge in plastic bags to preserve their freshness.',
        notificationDate: DateTime(2025, 3, 8),
        bestTimeDate: DateTime(2025, 3, 8),
      ),
      NotificationModel(
        title: 'Best Time for Planting: Peppers',
        description: 'Peppers should be planted in spring until early summer.',
        notificationDate: DateTime(2025, 3, 9),
        bestTimeDate: DateTime(2025, 3, 9),
      ),
      NotificationModel(
        title: 'Storage of Fresh Fruits',
        description: 'Fresh fruits should be stored in the fridge or in a cool place.',
        notificationDate: DateTime(2025, 3, 10),
        bestTimeDate: DateTime(2025, 3, 10),
      ),

    ];

    // DateFormatter to format DateTime objects
    final dateFormat = intl.DateFormat('yyyy-MM-dd');

    return Scaffold(
      appBar: PrimaryAppBar(
        title: 'Notifications',
      ),
      body: ListView.builder(
        itemCount: notifications.length,
        itemBuilder: (context, index) {
          final notification = notifications[index];

          return Directionality(
            textDirection: TextDirection.rtl,
            child: Card(
              // color: Colors.green.withOpacity(.1),
              margin: const EdgeInsets.all(8.0),
              child: ListTile(
                title: Text(
                  notification.title,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  children: [
                    Text(
                      notification.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Row(
                      children: [
                        Text(
                          'notification: ${dateFormat.format(notification.notificationDate)}',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                        SizedBox(width: 4),
                        // Text(
                        //   'أفضل وقت: ${dateFormat.format(notification.bestTimeDate)}',
                        //   style: TextStyle(fontSize: 12, color: Colors.grey),
                        // ),
                      ],
                    )

                  ],
                ),

              ),
            ),
          );
        },
      ),
    );
  }
}
