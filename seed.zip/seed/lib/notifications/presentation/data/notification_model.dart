// Define the Notification model
class NotificationModel {
  final String title;
  final String description;
  final DateTime notificationDate; // Date the notification was sent
  final DateTime bestTimeDate; // Best time for planting or storage

  NotificationModel({
    required this.title,
    required this.description,
    required this.notificationDate,
    required this.bestTimeDate,
  });
}